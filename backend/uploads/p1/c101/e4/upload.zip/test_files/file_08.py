# file_08.py
print('This is file 8')
