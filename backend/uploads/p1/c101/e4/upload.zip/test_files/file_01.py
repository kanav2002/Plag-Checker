# file_01.py
print('This is file 1')
