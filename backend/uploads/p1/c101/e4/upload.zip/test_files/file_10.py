# file_10.py
print('This is file 10')
