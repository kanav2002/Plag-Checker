# file_12.py
print('This is file 12')
