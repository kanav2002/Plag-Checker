# file_05.py
print('This is file 5')
