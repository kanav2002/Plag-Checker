# file_20.py
print('This is file 20')
