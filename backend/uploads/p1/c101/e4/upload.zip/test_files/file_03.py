# file_03.py
print('This is file 3')
