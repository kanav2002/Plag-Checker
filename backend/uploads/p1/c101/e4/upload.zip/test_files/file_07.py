# file_07.py
print('This is file 7')
