# file_04.py
print('This is file 4')
