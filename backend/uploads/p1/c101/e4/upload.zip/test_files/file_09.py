# file_09.py
print('This is file 9')
