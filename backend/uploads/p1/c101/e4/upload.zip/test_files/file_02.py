# file_02.py
print('This is file 2')
