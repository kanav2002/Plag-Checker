# file_18.py
print('This is file 18')
